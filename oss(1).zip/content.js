var i=false;
var xpos=0;
var ypos=0;


function init() {


	if (window.Event) {
	document.captureEvents(Event.MOUSEMOVE);
	}
	document.onmousemove = getCursorXY;

}

function getCursorXY(e) {
	xpos = (window.Event) ? e.pageX : event.clientX + (document.documentElement.scrollLeft ? document.documentElement.scrollLeft : document.body.scrollLeft);
	ypos = (window.Event) ? e.pageY : event.clientY + (document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop);
}



function start()
{
	

	init();
	var m = document.getElementsByTagName("a");
	for(i=0;i<m.length;i++)
	{    
	m[i].onmouseover=function(){
		if(i==true)remove();
	
	trends_dom = document.createElement('div');
	trends_dom1=document.createElement('div');
	var aElemTN = document.createTextNode("jiit");
    //trends_dom.appendChild(aElemTN);

	trends_dom.style.zIndex = '10';
	
	trends_dom.style.left=""+xpos+"px"; 
	trends_dom.style.top=""+ypos+"px"; 
	trends_dom.style.backgroundImage="url("+chrome.extension.getURL("bg.png")+")";

	


	trends_dom.style.border='1px' ;
	trends_dom.style.solid='#464f5a';
	trends_dom.style.position = 'absolute';
	trends_dom.style.height= '190px';
	trends_dom.style.width= '243px';
	var x = this.href;
	trends_dom1.innerHTML="<iframe src='http://images.websnapr.com/?size=S&key=7W913p15C5Wj&url="+this.href+"' scrolling='no' width='202' height='148'></iframe>";
	trends_dom.appendChild(trends_dom1);
	trends_dom1.style.position = 'relative';
	trends_dom1.style.left='23px'; 
	trends_dom1.style.top='28px'; 
	trends_dom1.style.display='block';

	
	document.body.insertBefore(trends_dom, document.body.firstChild);
	i=true;
	};
	
	m[i].onmouseout=function()
	{
		remove();	
		
	};
	
	}


}	
function remove()
{
			var a = trends_dom.parentNode;
			a.removeChild(trends_dom);
			i=false;
			
}

function keyUp(e)
{

var KeyID = event.keyCode;
if(KeyID==17)
{	
var m = document.getElementsByTagName("a");
	
for(i=0;i<m.length;i++)
	{    
	m[i].onmouseover=null;
	}
	
}
}

function keyDown(e)
{

var KeyID = event.keyCode;
if(KeyID==17)
	{
	
	start();
	}
}
document.onkeydown=keyDown;
document.onkeyup=keyUp;
